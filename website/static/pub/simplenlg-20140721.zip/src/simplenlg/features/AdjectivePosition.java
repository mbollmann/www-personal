/* ==================================================
 * SimpleNLG-Ger: An Adaption of SimpleNLG for German
 * ==================================================
 * 
 * Copyright (c) 2013, Marcel Bollmann
 * All rights reserved.
 * 
 * This package is a modification of "SimpleNLG: An API for Natural Language Generation".
 * The license of the original software is reproduced below and also applies to this
 * modification.
 * 
 * ==================================================
 * SimpleNLG: An API for Natural Language Generation
 * ==================================================
 *
 * Copyright (c) 2007, the University of Aberdeen
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted FOR RESEARCH PURPOSES ONLY, provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice, 
 * 		this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 3. Neither the name of the University of Aberdeen nor the names of its contributors 
 * 	  may be used to endorse or promote products derived from this software without 
 *    specific prior written permission.
 *    
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 *    ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE 
 *    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 *    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *     LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 *     ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *     (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 *     EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *     
 *  Redistribution and use for purposes other than research requires special permission by the
 *  copyright holders and contributors. Please contact Ehud Reiter (ereiter@csd.abdn.ac.uk) for
 *  more information.
 *     
 *	   =================    
 *     Acknowledgements:
 *     =================
 *     This library contains a re-implementation of some rules derived from the MorphG package
 *     by Guido Minnen, John Carroll and Darren Pearce. You can find more information about MorphG
 *     in the following reference:
 *     	Minnen, G., Carroll, J., and Pearce, D. (2001). Applied Morphological Processing of English.
 *     		Natural Language Engineering 7(3): 207--223.
 *     Thanks to John Carroll (University of Sussex) for permission to re-use the MorphG rules. 
 */
package simplenlg.features;

/**
 * Enumerated type specifying the possible syntactic positions that an adjective
 * takes. These values are not mutually exclusive for a given item.
 * 
 * @author agatt
 * @since Version 3.7
 */
public enum AdjectivePosition implements Feature {

	/**
	 * Attributive, prenominal adjective, position 1. This is the position of
	 * adjectives like <I>large</I>, which precede other adjectives when there
	 * is more than one prenominally. Example: <I><U>large</U>, red car</I>.
	 */
	ATTRIB_1,

	/**
	 * Attributive, prenominal adjective, position 2. This is the position of
	 * adjectives like <I>red</I>, which come after an adjective with position
	 * {@link #ATTRIB_1}. Example: <I>large, <U>red</U> car</I>.
	 */
	ATTRIB_2,

	/**
	 * Attributive, prenominal adjective, position 3. This is the position of
	 * adjectives like <I>cultural</I>, which tend to take the last position in
	 * the prenominal adjective phrase.
	 */
	ATTRIB_3,

	/**
	 * Indicates an attributive adjective which can take a complement. For
	 * example: <I>This was an <U>easy</U> problem <U>to solve</U></I>. This
	 * feature is useful to indicate the possibility of a syntactic dependency
	 * between discontinuous constituents (in this case <I>easy</I> and <I>to
	 * solve</I>).
	 */
	ATTRIB_C,

	/**
	 * Indicates that the adjective appears post-nominally in a noun phrase,
	 * example <I>the man <U>responsible</U> for the chaos</I>
	 */
	POST_NOMINAL,

	/**
	 * Indicates that the adjective can appear in predicative position (as the
	 * object of the verb <I>be</I>), example <I>he is <U>tall</U></I>
	 */
	PREDICATIVE;

	/*
	 * (non-Javadoc)
	 * 
	 * @see simplenlg.features.Feature#appliesTo(simplenlg.features.Category)
	 */
	public boolean appliesTo(Category cat) {
		return cat.equals(Category.ADJECTIVE);
	}
}
